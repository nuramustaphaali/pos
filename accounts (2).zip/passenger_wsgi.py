import os
import sys


from pos_system.wsgi import application